const express = require("express");
const path = require("path");
const cors = require("cors");
const Database = require("better-sqlite3");

// Setup
const app = express();
const db = new Database("./database.db");
app.use(express.json());
app.use(cors());

// Serve senen.html on root
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "senen.html"));
});

// GET all bookings for a court and date
app.get("/bookings", (req, res) => {
  const { court_id, tanggal } = req.query;

  try {
    const stmt = db.prepare(
      "SELECT * FROM bookings WHERE court_id = ? AND tanggal = ?",
    );
    const rows = stmt.all(court_id, tanggal);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST new booking
app.post("/bookings", (req, res) => {
  const { court_id, jam, nama, hp, tanggal } = req.body;

  try {
    const check = db
      .prepare(
        "SELECT * FROM bookings WHERE court_id = ? AND jam = ? AND tanggal = ?",
      )
      .get(court_id, jam, tanggal);

    if (check) {
      res.status(400).json({ error: "Slot sudah dibooking!" });
    } else {
      const stmt = db.prepare(
        "INSERT INTO bookings (court_id, jam, nama, hp, tanggal) VALUES (?, ?, ?, ?, ?)",
      );
      const info = stmt.run(court_id, jam, nama, hp, tanggal);
      res.json({ id: info.lastInsertRowid });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE bookings by date
app.delete("/bookings", (req, res) => {
  const { tanggal } = req.query;

  try {
    const stmt = db.prepare("DELETE FROM bookings WHERE tanggal = ?");
    const info = stmt.run(tanggal);
    res.json({ deleted: info.changes });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Server is running at http://localhost:${PORT}`);
});
