const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

// Koneksi ke database SQLite
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error('Gagal konek ke database:', err.message);
  } else {
    console.log('Berhasil konek ke database SQLite');
  }
});

// Endpoint untuk ambil semua booking
app.get('/bookings', (req, res) => {
  const { court_id, tanggal } = req.query;
  db.all(
    'SELECT * FROM bookings WHERE court_id = ? AND tanggal = ?',
    [court_id, tanggal],
    (err, rows) => {
      if (err) {
        res.status(500).json({error: err.message});
        return;
      }
      res.json(rows);
    }
  );
});

// Endpoint untuk tambah booking
app.post('/bookings', (req, res) => {
  const { court_id, jam, nama, hp, tanggal } = req.body;
  db.get(
    'SELECT * FROM bookings WHERE court_id = ? AND jam = ? AND tanggal = ?',
    [court_id, jam, tanggal],
    (err, row) => {
      if (row) {
        res.status(400).json({error: 'Slot sudah dibooking!'});
      } else {
        db.run(
          'INSERT INTO bookings (court_id, jam, nama, hp, tanggal) VALUES (?, ?, ?, ?, ?)',
          [court_id, jam, nama, hp, tanggal],
          function(err) {
            if (err) {
              res.status(500).json({error: err.message});
              return;
            }
            res.json({id: this.lastID});
          }
        );
      }
    }
  );
});

app.delete('/bookings', (req, res) => {
  const { tanggal } = req.query;
  db.run('DELETE FROM bookings WHERE tanggal = ?', [tanggal], function(err) {
    if (err) {
      res.status(500).json({error: err.message});
      return;
    }
    res.json({deleted: this.changes});
  });
});

app.listen(3000, () => {
  console.log('Server jalan di http://localhost:3000');
});